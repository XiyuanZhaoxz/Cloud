from application_services.BaseApplicationResource import BaseRDBApplicationResource
import database_services.RDBService as d_service


class XiyuanZhaoResource(BaseRDBApplicationResource):

    def __init__(self):
        super().__init__()

    @classmethod
    def get_links(cls, resource_data):
        pass

    @classmethod
    def get_data_resource_info(cls):
        pass

    @classmethod
    def get_by_age(cls, db_schema, table_name, column_name, age):
        res = d_service.RDBService.get_by_prefix(db_schema, table_name,
                                      column_name, age)

        return res

    @classmethod
    def user_get_by_age(cls):
        res = d_service.RDBService.get_by_prefix("XiyuanZhaoTest", "Test",
                                      "Age", "")

    @classmethod
    def get_restaurant_by_rid(cls,rid):
        res = d_service.RDBService.get_by_prefix("hw1_db", "restaurants",
                                                 "rid", rid)

        return res

    @classmethod
    def update_restaurant_name_by_rid(cls,rid, new_restaurant_name):
        res = d_service.RDBService.update_by_prefix(rid, new_restaurant_name)

        return res

    @classmethod
    def insert_restaurant(cls,rid,name,owner,type,location,links):
        res = d_service.RDBService.insert_by_prefix(rid,name,owner,type,location,links)

        return res


        return res