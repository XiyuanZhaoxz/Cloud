from flask import Flask, Response
from flask_cors import CORS
import json
import logging

from application_services.imdb_artists_resource import IMDBArtistResource
from application_services.UserResource import XiyuanZhaoResource
from application_services.UsersResource.user_service import UserResource
from database_services.RDBService import RDBService as RDBService

logging.basicConfig(level=logging.DEBUG)
logger = logging.getLogger()
logger.setLevel(logging.INFO)

app = Flask(__name__)
CORS(app)


@app.route('/')
def hello_world():
    return '<u>Hello World!</u>'


@app.route('/imdb/artists/<prefix>')
def get_artists_by_prefix(prefix):
    res = IMDBArtistResource.get_by_name_prefix(prefix)
    rsp = Response(json.dumps(res), status=200, content_type="application/json")
    return rsp


@app.route('/XiyuanZhaoTest/<db_schema>/<table_name>/<column_name>/<age>')
def get_by_age(db_schema, table_name, column_name, age):
    res = XiyuanZhaoResource.get_by_age(db_schema, table_name, column_name, age)
    rsp = Response(json.dumps(res), status=200, content_type="application/json")
    return rsp


@app.route('/users')
def get_users():
    res = XiyuanZhaoResource.user_get_by_age()
    rsp = Response(json.dumps(res), status=200, content_type="application/json")
    return rsp

'''
@app.route('/<db_schema>/<table_name>/<column_name>/<prefix>')
def get_by_prefix(db_schema, table_name, column_name, prefix):
    res = RDBService.get_by_prefix(db_schema, table_name, column_name, prefix)
    rsp = Response(json.dumps(res, default=str), status=200, content_type="application/json")
    return rsp
    '''

@app.route('/hw1_db/restaurants/search/rid/<rid>')
def get_restaurant_by_rid(rid):
    res = XiyuanZhaoResource.get_restaurant_by_rid(rid)
    rsp = Response(json.dumps(res, default=str), status=200, content_type="application/json")
    return rsp

@app.route('/hw1_db/restaurants/update/<rid>/<new_restaurant_name>')
def update_restaurant_by_rid(rid,new_restaurant_name):
    res = XiyuanZhaoResource.update_restaurant_name_by_rid(rid,new_restaurant_name)
    rsp = Response(json.dumps(res, default=str), status=200, content_type="application/json")
    return "Restaurant name updated successfully!"


@app.route('/hw1_db/restaurants/insert/<rid>/<name>/<owner>/<type>/<location>/<links>')
def insert_restaurant(rid,name,owner,type,location,links):
    res = XiyuanZhaoResource.insert_restaurant(rid,name,owner,type,location,links)
    rsp = Response(json.dumps(res, default=str), status=200, content_type="application/json")
    return "Restaurant successfully inserted!"


if __name__ == '__main__':
    app.run(host="0.0.0.0", port=5000)
